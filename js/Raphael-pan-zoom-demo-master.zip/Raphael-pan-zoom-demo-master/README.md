# Running with following commands

+ npm install
+ node node_modules/webserver/webserver.js